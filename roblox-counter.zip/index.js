const express = require('express');
const axios = require('axios');
const cors = require('cors');
const app = express();
const port = process.env.PORT || 3000;

// Abilita CORS per tutte le richieste
app.use(cors());

app.get('/', async (req, res) => {
  try {
    // Il tuo nuovo Universe ID (quello corretto)
    const universeId = 106425431775947;

    const response = await axios.get(
      `https://games.roblox.com/v1/games?universeIds=${universeId}`
    );

    const data = response.data;
    const visitCount = data.data[0]?.visits || 0;

    res.json({ visits: visitCount });
  } catch (error) {
    console.error('Errore durante il recupero dei dati:', error.message);
    res.status(500).json({ error: 'Errore durante il recupero dei dati' });
  }
});

app.listen(port, () => {
  console.log(`Server avviato sulla porta ${port}`);
});
