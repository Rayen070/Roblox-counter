
import fetch from 'node-fetch';

export default async function handler(req, res) {
  const universeId = '5286508223';
  const url = `https://games.roblox.com/v1/games?universeIds=${universeId}`;

  try {
    const response = await fetch(url);
    const data = await response.json();
    const visits = data.data[0].visits;

    res.setHeader('Access-Control-Allow-Origin', '*');
    res.status(200).json({ visits });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch visit data' });
  }
}
