const express = require("express");
const axios = require("axios");
const app = express();
const port = 3000;

const universeId = 5369392925; // Universe ID corretto per Motorcycle Racing

app.get("/", async (req, res) => {
  try {
    const response = await axios.get(`https://games.roblox.com/v1/games?universeIds=${universeId}`);
    const visits = response.data.data[0].visits;
    res.send(`<h1>Total Visits: ${visits.toLocaleString()}</h1>`);
  } catch (error) {
    console.error("Error fetching visit data:", error);
    res.status(500).send("Error fetching visit data");
  }
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});