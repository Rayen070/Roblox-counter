# motorcycle-visits

API endpoint for real Roblox visit counter.

Deploy on [Vercel](https://vercel.com) and get a link like:
```
https://<your-vercel-project>.vercel.app/api/visits
```
